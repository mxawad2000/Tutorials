package com.example.myapplication;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.List;

public class DoctorAdapter extends BaseAdapter {
    private Context context;
    private List<Doctor> items;

    public DoctorAdapter(Context c, List<Doctor> items) {
        context = c; this.items = items;
    }

    @Override public int getCount() {
        return items.size();
    }

    @Override public Object getItem(int position) {
        return items.get(position); }

    @Override public long getItemId(int position) {
        return position;  }

    @Override public View getView(int position, View view,
                                  ViewGroup parent){
        if(view == null){
            LayoutInflater inflter = (LayoutInflater.from(context));
            view = inflter.inflate(R.layout.doctor_item1, null);
        }

        Doctor doctor = items.get(position);
        TextView nameTV = view.findViewById(R.id.doc_name_tv);
        nameTV.setText(doctor.getName());
        //set the doctor image
        ImageView iv = view.findViewById(R.id.doc_iv);
        iv.setImageResource(R.drawable.doctor_male);
        if(doctor.getGender().equalsIgnoreCase("f")) iv.setImageResource(R.drawable.doctor_female);
        //set the doctor id
        TextView idTV = view.findViewById(R.id.doc_id_tv);
        idTV.setText(doctor.getId());
        //set the specialty
        TextView specTV = view.findViewById(R.id.specialty_tv);
        specTV.setText(doctor.getSpecialty());
        //
        return view;
    }
}
