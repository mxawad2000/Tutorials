package com.example.myapplication;

import android.content.res.AssetManager;
import android.util.Log;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutput;
import java.io.ObjectOutputStream;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Scanner;

public class DoctorController {
    private final Map<String,Doctor> doctors = new HashMap<>();
    private static final DoctorController instance = new DoctorController();
    public static DoctorController getInstance(){
        return instance;
    }
    private DoctorController(){
        Log.i("MyApp","getting doctors");
        if(!loadDoctors()){
            try {
                readFromAssets();
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
        }
        save();
        Log.i("MyApp","getting doctors:" + doctors.toString());
    }
    private void readFromAssets(){
        Log.i("MyApp","getting doctors from assets");
        AssetManager mgr = MyApp.getInstance().getAssets();
        try {
            Scanner sc = new Scanner( mgr.open("doctors2.txt"));
            while(sc.hasNext()) {
                String line = sc.nextLine();
                if(line.startsWith("#")) continue;
                String[] fields = line.split(",");
                Doctor d = new Doctor();
                d.setId(fields[0].trim());
                d.setName(fields[1].trim());
                d.setGender(fields[3].trim());
                d.setSpecialty(fields[2].trim());
                doctors.put(d.getId(), d);
            }
        }catch(Exception ex){
            Log.i("MyApp", Objects.requireNonNull(ex.getMessage()));
        }
    }

    public List<Doctor> getDoctorsBySpecialty(String specialty){
        List<Doctor> list = new ArrayList<>();
        for(Doctor d : this.doctors.values()){
            if(d.getSpecialty().equalsIgnoreCase(specialty)){
                list.add(d);
            }
        }
        return list;
    }
    public Doctor getDoctorById(String id){
        return doctors.get(id);
    }
    public void save(){
        try {
            File f = new File(
                    MyApp.getInstance().getExternalFilesDir(""),
                    "doctors.obj");
            ObjectOutputStream oos = new ObjectOutputStream(Files.newOutputStream(f.toPath()));
            oos.writeObject(doctors);
            oos.close();
        }catch(Exception ex){
            Log.i("MyApp", Objects.requireNonNull(ex.getMessage()));
        }
    }
    public boolean loadDoctors(){
        try {
            File f = new File(
                    MyApp.getInstance().getExternalFilesDir(""),
                    "doctors.obj");
            if(f.exists()) {
                ObjectInputStream ois = new ObjectInputStream(Files.newInputStream(f.toPath()));
                @SuppressWarnings("unchecked")
                HashMap<String,Doctor> map = (HashMap<String,Doctor>) ois.readObject();
                this.doctors.putAll(map);
                ois.close();
                Log.i("MyApp","getting doctors from external storage");
                return true;
            }else return false;
        }catch(Exception ex){
            Log.i("MyApp", Objects.requireNonNull(ex.getMessage()));
            return false;
        }
    }
    public List<Doctor> getAllDoctors(){
        return new ArrayList<>(this.doctors.values());
    }
}
