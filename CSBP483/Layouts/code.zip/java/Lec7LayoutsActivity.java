package com.example.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.GridView;
import android.widget.ListView;
import android.widget.PopupMenu;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContract;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityOptionsCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.ArrayList;
import java.util.List;

public class Lec7LayoutsActivity extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_lec7_layouts);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        //setGridViewFromResource();
        //setGridViewFromList();
        setCustomGridView();
        setCustomListView();
    }

    void setGridViewFromResource(){
        ArrayAdapter<String> adapter =new ArrayAdapter<>(
                this,
                android.R.layout.simple_list_item_1,
                getResources().getStringArray(R.array.ad_cities) ) ;
        GridView gv = findViewById(R.id.gv);
        gv.setAdapter(adapter);
        gv.setOnItemClickListener(
                (parent, view, position, rowId) -> {
                    TextView tv = (TextView) view;
                    Toast.makeText(this,
                            tv.getText().toString() + " was Tapped..",
                            Toast.LENGTH_SHORT).show();
                }
        );
    }
    void setGridViewFromList(){
        List<String> list = new ArrayList<>();
        list.add("Salim"); list.add("Fatima"); list.add("Jasim");
        list.add("James"); list.add("Kenu");

        ArrayAdapter<String> adapter =new ArrayAdapter<>(
                this,
                android.R.layout.select_dialog_item,
                list) ;
        GridView gv = findViewById(R.id.gv);
        gv.setAdapter(adapter);
        gv.setOnItemClickListener(
                (parent, view, position, rowId) -> {
                     //if you click Salim, add Salima..
                    TextView tv = (TextView) view;
                    String name = tv.getText().toString();
                    if(name.equalsIgnoreCase("Salim")){
                        list.add("Salima");
                    }else if(name.equalsIgnoreCase("Salima")){
                        list.remove("Salima");
                    }
                    adapter.notifyDataSetChanged();
                }
        );
    }
    void setCustomGridView(){
        List<Doctor> doctors = DoctorController.getInstance().getAllDoctors();
        DoctorAdapter adapter = new DoctorAdapter(this, doctors);
        GridView gv = findViewById(R.id.gv);
        gv.setAdapter(adapter);
        gv.setOnItemClickListener(
                (parent, view, position, rowId) -> {
                    showMenu(view);
                }
        );
    }
    public void showMenu(View view) {
        PopupMenu menu = new PopupMenu(this,view);
        getMenuInflater().
                inflate(R.menu.bmenu,menu.getMenu());
        menu.show();
    }

    void setCustomListView(){
        List<Doctor> doctors = DoctorController.getInstance().getAllDoctors();
        DoctorAdapter adapter = new DoctorAdapter(this, doctors);
        ListView myListView = findViewById(R.id.lv);
        myListView.setAdapter(adapter);
    }

    @Override public boolean onCreateOptionsMenu(Menu menu){
        getMenuInflater().inflate(R.menu.main_menu,menu);
        return true;
    }

    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if(id == R.id.twitter){
            //go to twitter..
            Toast.makeText(this,"Go to Twitter...",Toast.LENGTH_SHORT).show();
        }else if(id == R.id.new_game){
            startActivity(new Intent(this, WelcomeActivity.class));
        }

        return super.onOptionsItemSelected(item);
    }













    @Override public void onStart(){ super.onStart(); Log.i("MyApp","OnStart Lec7");}
    @Override public void onRestart(){ super.onRestart(); Log.i("MyApp","OnRestart Lec7");}
    @Override public void onPause(){ super.onPause(); Log.i("MyApp","OnPause Lec7");}
    @Override public void onStop(){ super.onStop(); Log.i("MyApp","OnStop Lec7");}
    ActivityResultLauncher<Intent> launcher = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(),
            (result) -> {
                Intent intent = result.getData();
                String msg = intent.getExtras().getString("msg");
                Toast.makeText(this,"message:" + msg, Toast.LENGTH_SHORT).show();
            }
    );
}